import javax.swing.JPanel;
import javax.swing.JButton;

public class Menu extends JPanel {

	private static final long serialVersionUID = 1L;

	/**
	 * Create the panel.
	 */
	public Menu() {
		
		JButton btnNewButton = new JButton("New button");
		add(btnNewButton);

	}

}
